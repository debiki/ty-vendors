package play.core

object PlayVersion {
  val current = "2.9.12-partitioned-cookies"
  val scalaVersion = "2.13.18"
  val sbtVersion = "1.13.0"
  val akkaVersion = "2.6.21"
  val akkaHttpVersion = "10.2.10"
  val jacksonVersion = "2.14.3"
  val sslConfigCoreVersion = "0.6.1"
}

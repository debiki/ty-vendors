/*
 * Copyright (C) from 2022 The Play Framework Contributors <https://github.com/playframework>, 2011-2021 Lightbend Inc. <https://www.lightbend.com>
 */

package play.db;

/**
 * A base for Java connection pool components.
 *
 * @see ConnectionPool
 */
public interface ConnectionPoolComponents {

  ConnectionPool connectionPool();
}

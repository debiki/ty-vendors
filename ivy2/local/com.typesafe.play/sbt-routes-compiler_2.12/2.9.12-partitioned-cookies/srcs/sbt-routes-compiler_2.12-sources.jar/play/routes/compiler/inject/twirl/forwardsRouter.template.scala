
package play.routes.compiler.inject.twirl

import _root_.play.twirl.api.TwirlFeatureImports._
import _root_.play.twirl.api.TwirlHelperImports._
import _root_.play.twirl.api.Html
import _root_.play.twirl.api.JavaScript
import _root_.play.twirl.api.Txt
import _root_.play.twirl.api.Xml
/*1.2*/import play.routes.compiler._
/*2.2*/import play.routes.compiler.templates._
/*3.2*/import InjectedRoutesGenerator.Dependency

object forwardsRouter extends _root_.play.twirl.api.BaseScalaTemplate[play.routes.compiler.ScalaFormat.Appendable,_root_.play.twirl.api.Format[play.routes.compiler.ScalaFormat.Appendable]](play.routes.compiler.ScalaFormat) with _root_.play.twirl.api.Template6[RoutesSourceInfo,Option[String],Seq[String],Seq[Dependency[Rule]],Seq[Dependency[Rule]],Seq[Dependency[Include]],play.routes.compiler.ScalaFormat.Appendable] {

  /**/
  def apply/*5.2*/(sourceInfo: RoutesSourceInfo, pkg: Option[String], imports: Seq[String],
  deps: Seq[Dependency[Rule]], rules: Seq[Dependency[Rule]], includes: Seq[Dependency[Include]]):play.routes.compiler.ScalaFormat.Appendable = {
    _display_ {
      {


Seq[Any](format.raw/*7.1*/("""// @GENERATOR:play-routes-compiler
// @SOURCE:"""),_display_(/*8.14*/sourceInfo/*8.24*/.source),format.raw/*8.31*/("""

"""),_display_(/*10.2*/for(p <- pkg) yield /*10.15*/ {_display_(Seq[Any](format.raw/*10.17*/("""package """),_display_(/*10.26*/p)))}),format.raw/*10.28*/("""

"""),format.raw/*12.1*/("""import play.core.routing._
import play.core.routing.HandlerInvokerFactory._

import play.api.mvc._
"""),_display_(/*16.2*/for(i <- imports) yield /*16.19*/ {_display_(Seq[Any](format.raw/*16.21*/("""
"""),format.raw/*17.1*/("""import """),_display_(if(!i.startsWith("_root_."))/*17.37*/{_display_(Seq[Any](format.raw/*17.38*/("""_root_.""")))} else {null} ),_display_(/*17.47*/i)))}),format.raw/*17.49*/("""

"""),format.raw/*19.1*/("""class Routes(
  override val errorHandler: play.api.http.HttpErrorHandler, """),_display_(/*20.63*/for(dep <- deps) yield /*20.79*/{_display_(Seq[Any](format.raw/*20.80*/("""
  """),_display_(/*21.4*/markLines(dep.rule)),format.raw/*21.23*/("""
  """),_display_(/*22.4*/dep/*22.7*/.ident),format.raw/*22.13*/(""": """),_display_(/*22.16*/dep/*22.19*/.clazz),format.raw/*22.25*/(""",""")))}),format.raw/*22.27*/("""
  """),format.raw/*23.3*/("""val prefix: String
) extends GeneratedRouter """),_display_(/*24.28*/ob),format.raw/*24.30*/("""

  """),format.raw/*26.3*/("""@javax.inject.Inject()
  def this(errorHandler: play.api.http.HttpErrorHandler"""),_display_(/*27.57*/for(dep <- deps) yield /*27.73*/ {_display_(Seq[Any](format.raw/*27.75*/(""",
    """),_display_(/*28.6*/markLines(dep.rule)),format.raw/*28.25*/("""
    """),_display_(/*29.6*/dep/*29.9*/.ident),format.raw/*29.15*/(""": """),_display_(/*29.18*/dep/*29.21*/.clazz)))}),format.raw/*29.28*/("""
  """),format.raw/*30.3*/(""") = this(errorHandler, """),_display_(/*30.27*/for(dep <- deps) yield /*30.43*/{_display_(Seq[Any](_display_(/*30.45*/dep/*30.48*/.ident),format.raw/*30.54*/(""", """)))}),format.raw/*30.57*/(""""/")

  def withPrefix(addPrefix: String): Routes = """),_display_(/*32.48*/ob),format.raw/*32.50*/("""
    """),format.raw/*33.5*/("""val prefix = play.api.routing.Router.concatPrefix(addPrefix, this.prefix)
    """),_display_(/*34.6*/(pkg.getOrElse("_routes_"))),format.raw/*34.33*/(""".RoutesPrefix.setPrefix(prefix)
    new Routes(errorHandler, """),_display_(/*35.31*/for(dep <- deps) yield /*35.47*/{_display_(Seq[Any](_display_(/*35.49*/dep/*35.52*/.ident),format.raw/*35.58*/(""", """)))}),format.raw/*35.61*/("""prefix)
  """),_display_(/*36.4*/cb),format.raw/*36.6*/("""

  """),format.raw/*38.3*/("""private val defaultPrefix: String = """),_display_(/*38.40*/ob),format.raw/*38.42*/("""
    """),format.raw/*39.5*/("""if (this.prefix.endsWith("/")) "" else "/"
  """),_display_(/*40.4*/cb),format.raw/*40.6*/("""

  """),format.raw/*42.3*/("""def documentation = List("""),_display_(/*42.29*/for((dep, index) <- rules.zipWithIndex) yield /*42.68*/ {_display_(Seq[Any](format.raw/*42.70*/("""
    """),_display_(/*43.6*/dep/*43.9*/.rule/*43.14*/ match/*43.20*/ {/*44.7*/case Route(verb, path, call, _, _) if path.parts.isEmpty =>/*44.66*/ {_display_(Seq[Any](format.raw/*44.68*/("""("""),_display_(/*44.70*/tq),_display_(/*44.73*/verb),_display_(/*44.78*/tq),format.raw/*44.80*/(""", this.prefix, """),_display_(/*44.96*/tq),_display_(/*44.99*/call),_display_(/*44.104*/tq),format.raw/*44.106*/(""")""")))}/*45.7*/case Route(verb, path, call, _, _) =>/*45.44*/ {_display_(Seq[Any](format.raw/*45.46*/("""("""),_display_(/*45.48*/tq),_display_(/*45.51*/verb),_display_(/*45.56*/tq),format.raw/*45.58*/(""", this.prefix + (if(this.prefix.endsWith("/")) "" else "/") + """),_display_(/*45.121*/encodeStringConstant(path.toString)),format.raw/*45.156*/(""", """),_display_(/*45.159*/tq),_display_(/*45.162*/call),_display_(/*45.167*/tq),format.raw/*45.169*/(""")""")))}/*46.7*/case include: Include =>/*46.31*/ {_display_(Seq[Any](format.raw/*46.33*/("""prefixed_"""),_display_(/*46.43*/(dep.ident)),format.raw/*46.54*/("""_"""),_display_(/*46.56*/(index)),format.raw/*46.63*/(""".router.documentation""")))}}),format.raw/*47.4*/(""",""")))}),format.raw/*47.6*/("""
    """),format.raw/*48.5*/("""Nil
  ).foldLeft(Seq.empty[(String, String, String)]) """),format.raw/*49.51*/("""{"""),format.raw/*49.52*/(""" """),format.raw/*49.53*/("""(s,e) => e.asInstanceOf[Any] match """),format.raw/*49.88*/("""{"""),format.raw/*49.89*/("""
    case r @ (_,_,_) => s :+ r.asInstanceOf[(String, String, String)]
    case l => s ++ l.asInstanceOf[List[(String, String, String)]]
  """),format.raw/*52.3*/("""}"""),format.raw/*52.4*/("""}"""),format.raw/*52.5*/("""

"""),_display_(/*54.2*/for((dep, index) <- rules.zipWithIndex) yield /*54.41*/{_display_(_display_(/*54.43*/dep/*54.46*/.rule/*54.51*/ match/*54.57*/ {/*55.1*/case route @ Route(verb, path, call, comments, modifiers) =>/*55.61*/ {_display_(Seq[Any](format.raw/*55.63*/("""
  """),_display_(/*56.4*/markLines(route)),format.raw/*56.20*/("""
  """),format.raw/*57.3*/("""private lazy val """),_display_(/*57.21*/routeIdentifier(route, index)),format.raw/*57.50*/(""" """),format.raw/*57.51*/("""= Route(""""),_display_(/*57.61*/verb/*57.65*/.value),format.raw/*57.71*/("""",
    PathPattern(List(StaticPart(this.prefix)"""),_display_(if(path.parts.nonEmpty)/*58.69*/ {_display_(Seq[Any](format.raw/*58.71*/(""", StaticPart(this.defaultPrefix), """)))} else {null} ),_display_(/*58.107*/path/*58.111*/.parts.map(_.toString).mkString(", ")),format.raw/*58.148*/("""))
  )
  private lazy val """),_display_(/*60.21*/invokerIdentifier(route, index)),format.raw/*60.52*/(""" """),format.raw/*60.53*/("""= createInvoker(
    """),_display_(if(route.call.passJavaRequest)/*61.36*/{_display_(Seq[Any](format.raw/*61.37*/("""
    """),format.raw/*62.5*/("""(req:play.mvc.Http.Request) =>
      """)))} else {null} ),_display_(/*63.9*/injectedControllerMethodCall(route, dep.ident, p => s"fakeValue[${p.typeNameReal}]")),format.raw/*63.93*/(""",
    play.api.routing.HandlerDef(this.getClass.getClassLoader,
      """"),_display_(/*65.9*/for(p <- pkg) yield /*65.22*/ {_display_(_display_(/*65.25*/p))}),format.raw/*65.27*/("""",
      """"),_display_(/*66.9*/{call.packageName.map(_ + ".").getOrElse("")}),_display_(/*66.55*/call/*66.59*/.controller),format.raw/*66.70*/("""",
      """"),_display_(/*67.9*/call/*67.13*/.method),format.raw/*67.20*/("""",
      """),_display_(/*68.8*/call/*68.12*/.parameters.filterNot(_.isEmpty).map(params => params.map("classOf[" + _.typeNameReal + "]").mkString(", ")).map("Seq(" + _ + ")").getOrElse("Nil")),format.raw/*68.159*/(""",
      """"),_display_(/*69.9*/verb),format.raw/*69.13*/("""",
      this.prefix + """),_display_(/*70.22*/encodeStringConstant(path.toString)),format.raw/*70.57*/(""",
      """),_display_(/*71.8*/encodeStringConstant(comments.map(_.comment).mkString("\n"))),format.raw/*71.68*/(""",
      Seq("""),_display_(/*72.12*/modifiers/*72.21*/.map(_.value).map(encodeStringConstant).mkString(", ")),format.raw/*72.75*/(""")
    )
  )
""")))}/*76.1*/case include @ Include(path, router) =>/*76.40*/ {_display_(Seq[Any](format.raw/*76.42*/("""
  """),_display_(/*77.4*/markLines(include)),format.raw/*77.22*/("""
  """),format.raw/*78.3*/("""private val prefixed_"""),_display_(/*78.25*/(dep.ident)),format.raw/*78.36*/("""_"""),_display_(/*78.38*/(index)),format.raw/*78.45*/(""" """),format.raw/*78.46*/("""= Include("""),_display_(/*78.57*/(dep.ident)),format.raw/*78.68*/(""".withPrefix(this.prefix + (if (this.prefix.endsWith("/")) "" else "/") + """"),_display_(/*78.143*/include/*78.150*/.prefix),format.raw/*78.157*/(""""))
""")))}}))}),format.raw/*79.4*/("""

  """),format.raw/*81.3*/("""def routes: PartialFunction[RequestHeader, Handler] = """),_display_(/*81.58*/ob),format.raw/*81.60*/("""
  """),_display_(if(rules.isEmpty)/*82.21*/ {_display_(Seq[Any](format.raw/*82.23*/("""
    """),format.raw/*83.5*/("""Map.empty
  """)))}else/*84.10*/{_display_(_display_(/*84.12*/for((dep, index) <- rules.zipWithIndex) yield /*84.51*/{_display_(_display_(/*84.53*/dep/*84.56*/.rule/*84.61*/ match/*84.67*/ {/*85.3*/case include: Include =>/*85.27*/ {_display_(Seq[Any](format.raw/*85.29*/("""
    """),_display_(/*86.6*/markLines(include)),format.raw/*86.24*/("""
    case prefixed_"""),_display_(/*87.20*/(dep.ident)),format.raw/*87.31*/("""_"""),_display_(/*87.33*/(index)),format.raw/*87.40*/("""(handler) => handler
  """)))}/*89.3*/case route: Route =>/*89.23*/ {_display_(Seq[Any](format.raw/*89.25*/("""
    """),_display_(/*90.6*/markLines(route)),format.raw/*90.22*/("""
    case """),_display_(/*91.11*/(routeIdentifier(route, index))),format.raw/*91.42*/("""(params@_) =>
      call"""),_display_(/*92.12*/(routeBinding(route))),format.raw/*92.33*/(""" """),_display_(/*92.35*/ob),format.raw/*92.37*/(""" """),_display_(/*92.39*/localNames(route)),format.raw/*92.56*/("""
        """),_display_(/*93.10*/(invokerIdentifier(route, index))),format.raw/*93.43*/(""".call("""),_display_(if(route.call.passJavaRequest)/*93.80*/{_display_(Seq[Any](format.raw/*93.81*/("""
          """),format.raw/*94.11*/("""req => """)))} else {null} ),_display_(/*94.20*/injectedControllerMethodCall(route, dep.ident, x => safeKeyword(x.nameClean))),format.raw/*94.97*/(""")
      """),_display_(/*95.8*/cb),format.raw/*95.10*/("""
  """)))}}))}))}),_display_(/*97.7*/cb),format.raw/*97.9*/("""
"""),_display_(/*98.2*/cb),format.raw/*98.4*/("""
"""))
      }
    }
  }

  def render(sourceInfo:RoutesSourceInfo,pkg:Option[String],imports:Seq[String],deps:Seq[Dependency[Rule]],rules:Seq[Dependency[Rule]],includes:Seq[Dependency[Include]]): play.routes.compiler.ScalaFormat.Appendable = apply(sourceInfo,pkg,imports,deps,rules,includes)

  def f:((RoutesSourceInfo,Option[String],Seq[String],Seq[Dependency[Rule]],Seq[Dependency[Rule]],Seq[Dependency[Include]]) => play.routes.compiler.ScalaFormat.Appendable) = (sourceInfo,pkg,imports,deps,rules,includes) => apply(sourceInfo,pkg,imports,deps,rules,includes)

  def ref: this.type = this

}


              /*
                  -- GENERATED --
                  SOURCE: dev-mode/play-routes-compiler/src/main/twirl/play/routes/compiler/inject/forwardsRouter.scala.twirl
                  HASH: fdd8d79f4a51aaa1332e1e7cd23af5911e36937e
                  MATRIX: 292->1|329->32|376->73|865->117|1136->288|1209->337|1227->347|1254->354|1283->357|1312->370|1352->372|1388->381|1414->383|1443->385|1569->485|1602->502|1642->504|1670->505|1733->541|1772->542|1824->551|1850->553|1879->555|1982->631|2014->647|2053->648|2083->652|2123->671|2153->675|2164->678|2191->684|2221->687|2233->690|2260->696|2293->698|2323->701|2396->747|2419->749|2450->753|2556->833|2588->849|2628->851|2661->858|2701->877|2733->883|2744->886|2771->892|2801->895|2813->898|2844->905|2874->908|2925->932|2957->948|2996->950|3008->953|3035->959|3069->962|3149->1015|3172->1017|3204->1022|3309->1101|3357->1128|3446->1190|3478->1206|3517->1208|3529->1211|3556->1217|3590->1220|3627->1231|3649->1233|3680->1237|3744->1274|3767->1276|3799->1281|3871->1327|3893->1329|3924->1333|3977->1359|4032->1398|4072->1400|4104->1406|4115->1409|4129->1414|4144->1420|4154->1429|4222->1488|4262->1490|4291->1492|4314->1495|4339->1500|4362->1502|4405->1518|4428->1521|4454->1526|4478->1528|4498->1537|4544->1574|4584->1576|4613->1578|4636->1581|4661->1586|4684->1588|4775->1651|4832->1686|4863->1689|4887->1692|4913->1697|4937->1699|4957->1708|4990->1732|5030->1734|5067->1744|5099->1755|5128->1757|5156->1764|5209->1790|5241->1792|5273->1797|5355->1851|5384->1852|5413->1853|5476->1888|5505->1889|5671->2029|5699->2030|5727->2031|5756->2034|5811->2073|5841->2075|5853->2078|5867->2083|5882->2089|5892->2092|5961->2152|6001->2154|6031->2158|6068->2174|6098->2177|6143->2195|6193->2224|6222->2225|6259->2235|6272->2239|6299->2245|6397->2316|6437->2318|6517->2354|6531->2358|6590->2395|6644->2422|6696->2453|6725->2454|6804->2506|6843->2507|6875->2512|6956->2551|7061->2635|7159->2707|7188->2720|7219->2723|7244->2725|7281->2736|7347->2782|7360->2786|7392->2797|7429->2808|7442->2812|7470->2819|7506->2829|7519->2833|7688->2980|7724->2990|7749->2994|7800->3018|7856->3053|7891->3062|7972->3122|8012->3135|8030->3144|8105->3198|8136->3212|8184->3251|8224->3253|8254->3257|8293->3275|8323->3278|8372->3300|8404->3311|8433->3313|8461->3320|8490->3321|8528->3332|8560->3343|8663->3418|8680->3425|8709->3432|8748->3439|8779->3443|8861->3498|8884->3500|8932->3521|8972->3523|9004->3528|9040->3547|9070->3549|9125->3588|9155->3590|9167->3593|9181->3598|9196->3604|9206->3609|9239->3633|9279->3635|9311->3641|9350->3659|9397->3679|9429->3690|9458->3692|9486->3699|9528->3726|9557->3746|9597->3748|9629->3754|9666->3770|9704->3781|9756->3812|9808->3838|9850->3859|9879->3861|9902->3863|9931->3865|9969->3882|10006->3892|10060->3925|10124->3962|10163->3963|10202->3974|10254->3983|10352->4060|10387->4069|10410->4071|10451->4082|10473->4084|10501->4086|10523->4088
                  LINES: 10->1|11->2|12->3|17->5|23->7|24->8|24->8|24->8|26->10|26->10|26->10|26->10|26->10|28->12|32->16|32->16|32->16|33->17|33->17|33->17|33->17|33->17|35->19|36->20|36->20|36->20|37->21|37->21|38->22|38->22|38->22|38->22|38->22|38->22|38->22|39->23|40->24|40->24|42->26|43->27|43->27|43->27|44->28|44->28|45->29|45->29|45->29|45->29|45->29|45->29|46->30|46->30|46->30|46->30|46->30|46->30|46->30|48->32|48->32|49->33|50->34|50->34|51->35|51->35|51->35|51->35|51->35|51->35|52->36|52->36|54->38|54->38|54->38|55->39|56->40|56->40|58->42|58->42|58->42|58->42|59->43|59->43|59->43|59->43|59->44|59->44|59->44|59->44|59->44|59->44|59->44|59->44|59->44|59->44|59->44|59->45|59->45|59->45|59->45|59->45|59->45|59->45|59->45|59->45|59->45|59->45|59->45|59->45|59->46|59->46|59->46|59->46|59->46|59->46|59->46|59->47|59->47|60->48|61->49|61->49|61->49|61->49|61->49|64->52|64->52|64->52|66->54|66->54|66->54|66->54|66->54|66->54|66->55|66->55|66->55|67->56|67->56|68->57|68->57|68->57|68->57|68->57|68->57|68->57|69->58|69->58|69->58|69->58|69->58|71->60|71->60|71->60|72->61|72->61|73->62|74->63|74->63|76->65|76->65|76->65|76->65|77->66|77->66|77->66|77->66|78->67|78->67|78->67|79->68|79->68|79->68|80->69|80->69|81->70|81->70|82->71|82->71|83->72|83->72|83->72|86->76|86->76|86->76|87->77|87->77|88->78|88->78|88->78|88->78|88->78|88->78|88->78|88->78|88->78|88->78|88->78|89->79|91->81|91->81|91->81|92->82|92->82|93->83|94->84|94->84|94->84|94->84|94->84|94->84|94->84|94->85|94->85|94->85|95->86|95->86|96->87|96->87|96->87|96->87|97->89|97->89|97->89|98->90|98->90|99->91|99->91|100->92|100->92|100->92|100->92|100->92|100->92|101->93|101->93|101->93|101->93|102->94|102->94|102->94|103->95|103->95|104->97|104->97|105->98|105->98
                  -- GENERATED --
              */
          